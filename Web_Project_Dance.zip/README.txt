This web project is made to advertise a "dancing academy" it
contains the following pages:

- Home: an introductory page about modern dancing related to ballet dancing. 
Inluded in that page are a header, a few paragraphs related to ballet 
and two images showing ballet.

- Gallery: this page contains two images that are set as links to the pages "tango"
and "waltz".

- tango: this page can be accessed through the Gallery page by clicking the image
showing tango (the leftmost image)

- waltz: this page can be accessed through the Gallery page by clicking the image
showing waltz (the rightmost image). 

- Information: this page contains the history of the dance academy.

- Contacts: this page contains a list with contacts (they are not valid)
and a few textboxes where a person could add information 
(currently they are not connected to anything)

- About: this page contains a table that showscases lesson packages 
related to the "dance academy".

-Logo: on this page is the logo of the academy.